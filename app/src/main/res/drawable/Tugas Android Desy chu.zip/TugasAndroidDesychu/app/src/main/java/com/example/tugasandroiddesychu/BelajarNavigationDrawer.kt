package com.example.tugasandroiddesychu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class BelajarNavigationDrawer : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_belajar_navigation_drawer)

        drawerLayout = findViewById<Drawer
    }
}