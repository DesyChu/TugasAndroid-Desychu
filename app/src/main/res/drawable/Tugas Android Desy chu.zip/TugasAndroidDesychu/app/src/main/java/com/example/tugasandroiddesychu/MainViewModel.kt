package com.example.tugasandroiddesychu

class MainViewModel:ViewModel() {
    var angka = 0
    var tambahAngka(){
        angka++

    }

}